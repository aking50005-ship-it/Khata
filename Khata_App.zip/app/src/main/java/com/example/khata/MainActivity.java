package com.example.khata;
import android.app.*; import android.os.*; import android.content.*; import android.view.*; import android.widget.*; import java.util.*;
public class MainActivity extends Activity{
 EditText name,amount; TextView balance; ArrayList<String> entries=new ArrayList<>(); ArrayAdapter<String> ad; double bal=0;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  name=findViewById(R.id.name);amount=findViewById(R.id.amount);balance=findViewById(R.id.balance);
  ListView list=findViewById(R.id.list); ad=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,entries);list.setAdapter(ad);
  findViewById(R.id.jama).setOnClickListener(v->add(true)); findViewById(R.id.udhar).setOnClickListener(v->add(false));
  findViewById(R.id.calc).setOnClickListener(v->calculator());
 }
 void add(boolean jama){String n=name.getText().toString().trim(),s=amount.getText().toString().trim();if(n.isEmpty()||s.isEmpty()){Toast.makeText(this,"Name aur amount likhein",0).show();return;}
  double x=Double.parseDouble(s);bal+=jama?x:-x;entries.add(0,(jama?"➕ JAMA  ":"➖ MINUS  ")+n+" : "+x);ad.notifyDataSetChanged();balance.setText("Balance: "+bal);amount.setText("");
 }
 void calculator(){ final EditText e=new EditText(this);e.setHint("Example: 100+50-20"); new AlertDialog.Builder(this).setTitle("Calculator").setView(e).setPositiveButton("Calculate",(d,w)->{try{String s=e.getText().toString().replace(" ","");double r=eval(s);new AlertDialog.Builder(this).setTitle("Result").setMessage(""+r).setPositiveButton("OK",null).show();}catch(Exception x){Toast.makeText(this,"Invalid calculation",0).show();}}).setNegativeButton("Cancel",null).show();}
 double eval(String s){double total=0;String[] p=s.split("(?=[+-])|(?<=[+-])");double cur=0;char op='+';for(String q:p){if(q.equals("+")||q.equals("-"))op=q.charAt(0);else{double v=Double.parseDouble(q);total=op=='+'?total+v:total-v;}}return total;}
}